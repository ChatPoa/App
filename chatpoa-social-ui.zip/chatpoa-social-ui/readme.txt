=== ChatPoa Social UI ===
Contributors: chatpoa
Tags: prototype, social network, demo
Requires at least: 5.8
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Embeds the ChatPoa social-network UI prototype into WordPress via a shortcode or a full-screen page template.

== Description ==

ChatPoa Social UI packages a self-contained HTML/CSS/JS front-end prototype (auth flow, feed, profile,
chat, groups, marketplace, settings, and more) as an installable WordPress plugin.

This is a **front-end prototype only** — all data (posts, people, messages) is mock data held in the
browser and resets on page reload. There is no database, no real user accounts, and no server-side
logic. It's meant for demos, stakeholder review, and as a starting point for a real build-out.

Two ways to use it once activated:

1. **Shortcode** — add `[chatpoa]` to any Page or Post. Renders as a framed, scrollable app panel inside
   your normal theme layout.
2. **Full Screen template** — create a new Page, and under Page Attributes set Template to
   "ChatPoa (Full Screen App)". The page will render edge-to-edge with no theme header/footer, like a
   real app.

== Installation ==

1. In your WordPress admin, go to Plugins → Add New → Upload Plugin.
2. Choose the `chatpoa-social-ui.zip` file and click Install Now.
3. Click Activate.
4. Add `[chatpoa]` to a page, or create a page using the "ChatPoa (Full Screen App)" template.

== Frequently Asked Questions ==

= Does this store any real data? =
No. All content is mock/sample data defined in the plugin's JavaScript. Nothing is saved to the
WordPress database.

= Will this affect the rest of my site's styling? =
No. All CSS is scoped under the `#chatpoa-app` container ID, so it won't leak into your theme, and all
JavaScript globals are namespaced to avoid clashing with other plugins.

= Can I use this alongside other plugins/themes? =
Yes — assets are only loaded on pages that actually use the shortcode or the full-screen template.

== Changelog ==

= 1.0.0 =
* Initial release.
