<?php
/**
 * Plugin Name: ChatPoa Social UI
 * Plugin URI:  https://example.com/chatpoa
 * Description: Embeds the ChatPoa social-network front-end prototype (HTML/CSS/JS) into any WordPress site via a shortcode, or as a dedicated full-screen page template. This is a click-through UI prototype (no database, no real accounts) intended for demos and design review.
 * Version:     1.0.0
 * Author:      ChatPoa
 * License:     GPL v2 or later
 * Text Domain: chatpoa
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

define( 'CHATPOA_VERSION', '1.0.0' );
define( 'CHATPOA_URL', plugin_dir_url( __FILE__ ) );
define( 'CHATPOA_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Register + enqueue the plugin's CSS/JS.
 * Called on demand (only when the shortcode is actually used on a page,
 * or when the full-screen template is active) so we never load unused
 * assets on the rest of the site.
 */
function chatpoa_register_assets() {
	// Third-party: Font Awesome (icons) + Inter (type), both loaded from their
	// official CDNs so there is nothing extra to host on your server.
	wp_register_style( 'chatpoa-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css', array(), '6.5.1' );
	wp_register_style( 'chatpoa-inter-font', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap', array(), null );

	wp_register_style( 'chatpoa-style', CHATPOA_URL . 'assets/css/chatpoa.css', array( 'chatpoa-fontawesome', 'chatpoa-inter-font' ), CHATPOA_VERSION );
	wp_register_script( 'chatpoa-script', CHATPOA_URL . 'assets/js/chatpoa.js', array(), CHATPOA_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'chatpoa_register_assets' );

function chatpoa_enqueue_assets() {
	wp_enqueue_style( 'chatpoa-style' );
	wp_enqueue_script( 'chatpoa-script' );
}

/**
 * Shortcode: [chatpoa]
 * Drop this into any Page or Post to embed ChatPoa as a framed, scrollable
 * app panel (~85vh tall) inside your normal theme layout.
 */
function chatpoa_shortcode( $atts ) {
	chatpoa_enqueue_assets();
	return '<div id="chatpoa-app" class="chatpoa-embed" data-theme="light"></div>';
}
add_shortcode( 'chatpoa', 'chatpoa_shortcode' );

/**
 * Full-screen page template.
 * Adds "ChatPoa (Full Screen App)" to the Template dropdown under
 * Page Attributes, so a page can render ChatPoa edge-to-edge with no
 * theme header/footer — the recommended way to present the full app.
 */
function chatpoa_register_page_template( $templates ) {
	$templates['chatpoa-fullscreen.php'] = 'ChatPoa (Full Screen App)';
	return $templates;
}
add_filter( 'theme_page_templates', 'chatpoa_register_page_template' );

function chatpoa_load_page_template( $template ) {
	if ( is_page() && get_page_template_slug() === 'chatpoa-fullscreen.php' ) {
		chatpoa_enqueue_assets();
		$custom = CHATPOA_PATH . 'templates/full-screen.php';
		if ( file_exists( $custom ) ) {
			return $custom;
		}
	}
	return $template;
}
add_filter( 'template_include', 'chatpoa_load_page_template' );

/**
 * Friendly admin notice with setup steps, shown once on the Plugins page
 * after activation.
 */
function chatpoa_activation_notice() {
	if ( ! get_transient( 'chatpoa_activated_notice' ) ) {
		return;
	}
	delete_transient( 'chatpoa_activated_notice' );
	?>
	<div class="notice notice-success is-dismissible">
		<p><strong>ChatPoa Social UI is active.</strong>
		Add it to a page with the <code>[chatpoa]</code> shortcode, or create a new Page and set its
		<em>Template</em> (in Page Attributes) to <strong>"ChatPoa (Full Screen App)"</strong> for an
		edge-to-edge experience.</p>
	</div>
	<?php
}
add_action( 'admin_notices', 'chatpoa_activation_notice' );

function chatpoa_on_activate() {
	set_transient( 'chatpoa_activated_notice', true, 30 );
}
register_activation_hook( __FILE__, 'chatpoa_on_activate' );
