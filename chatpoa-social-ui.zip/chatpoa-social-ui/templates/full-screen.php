<?php
/**
 * Full-screen ChatPoa template.
 * Deliberately does NOT call get_header()/get_footer() so the theme's
 * chrome (header, footer, sidebars) is skipped and ChatPoa fills the
 * entire browser viewport, app-style.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title><?php wp_title( '' ); ?></title>
	<?php wp_head(); ?>
	<style>
		html, body { margin: 0; padding: 0; }
		#wpadminbar { position: fixed; }
	</style>
</head>
<body <?php body_class( 'chatpoa-fullscreen-page' ); ?>>
	<div id="chatpoa-app" class="chatpoa-fullscreen" data-theme="light"></div>
	<?php wp_footer(); ?>
</body>
</html>
