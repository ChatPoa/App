/* =================================================================
   ICON HELPER — Font Awesome 6 Free via cdnjs
================================================================= */
function cpIcon(name, size, color){
  size = size || 16; color = color ? `color:${color};` : '';
  return `<i class="fa-solid fa-${name}" style="font-size:${size}px;${color}"></i>`;
}

/* =================================================================
   MOCK DATA
================================================================= */
const CPME = { name:"Jordan Lee", handle:"@jordanlee", initials:"JL", grad:"linear-gradient(135deg,#2F6BFF,#17C3E6)" };
const PEOPLE = [
  { name:"Maya Chen", handle:"@mayachen", initials:"MC", grad:"linear-gradient(135deg,#7C4DFF,#2F6BFF)", verified:true },
  { name:"Diego Alvarez", handle:"@diegoalvarez", initials:"DA", grad:"linear-gradient(135deg,#17C3E6,#22C55E)" },
  { name:"Priya Nair", handle:"@priyanair", initials:"PN", grad:"linear-gradient(135deg,#F5A623,#EF4444)", verified:true },
  { name:"Tom Becker", handle:"@tombecker", initials:"TB", grad:"linear-gradient(135deg,#2F6BFF,#7C4DFF)" },
  { name:"Aisha Bello", handle:"@aishabello", initials:"AB", grad:"linear-gradient(135deg,#EF4444,#F5A623)" },
  { name:"Noah Kim", handle:"@noahkim", initials:"NK", grad:"linear-gradient(135deg,#17C3E6,#2F6BFF)" },
];
let POSTS = [
  { id:1, user:PEOPLE[0], time:"12m", text:"Shipped the redesign today. Small team, six weeks, way too much coffee. Proud of this one.", likes:482, comments:61, tag:"product", liked:false },
  { id:2, user:PEOPLE[1], time:"40m", text:"Unpopular opinion: the best meetings are the ones that get cancelled.", likes:219, comments:34, liked:false },
  { id:3, user:PEOPLE[2], time:"1h", text:"Just hit 10 years at the same company. Wrote up what actually kept me here — link in comments.", likes:903, comments:128, tag:"career", liked:false },
];
const GROUPS = [
  { name:"Product Design Weekly", members:"48.2K", cover:"linear-gradient(135deg,#2F6BFF,#17C3E6)" },
  { name:"Remote Work Collective", members:"112K", cover:"linear-gradient(135deg,#7C4DFF,#2F6BFF)" },
  { name:"Indie Makers", members:"29.8K", cover:"linear-gradient(135deg,#17C3E6,#22C55E)" },
];
const EVENTS = [
  { name:"ChatPoa Creator Summit", date:"Aug 14", loc:"Austin, TX", cover:"linear-gradient(135deg,#2F6BFF,#17C3E6)" },
  { name:"Design Systems Meetup", date:"Aug 22", loc:"Online", cover:"linear-gradient(135deg,#7C4DFF,#EF4444)" },
];
const PRODUCTS = [
  { name:"Studio desk lamp", price:"$68", seller:PEOPLE[3], cover:"linear-gradient(135deg,#F5A623,#EF4444)" },
  { name:"Mechanical keyboard", price:"$140", seller:PEOPLE[4], cover:"linear-gradient(135deg,#2F6BFF,#7C4DFF)" },
  { name:"Vintage camera", price:"$210", seller:PEOPLE[5], cover:"linear-gradient(135deg,#17C3E6,#22C55E)" },
];
const CONVERSATIONS = [
  { id:1, person:PEOPLE[0], last:"That mockup looks great, ship it", time:"2m", unread:2 },
  { id:2, person:PEOPLE[1], last:"Sent the files over", time:"1h", unread:0 },
  { id:3, person:PEOPLE[2], last:"See you at the summit", time:"3h", unread:1 },
];
let CHAT_THREADS = { 1:[{mine:false,text:"That mockup looks great, ship it"},{mine:true,text:"On it, deploying tonight"}], 2:[{mine:false,text:"Sent the files over"}], 3:[{mine:false,text:"See you at the summit"}] };
const NOTIFS = [
  { person:PEOPLE[0], text:"liked your post.", time:"2m", icon:"heart", color:"#EF4444" },
  { person:PEOPLE[1], text:"started following you.", time:"38m", icon:"user-plus", color:"#2F6BFF" },
  { person:PEOPLE[2], text:"commented on your post.", time:"1h", icon:"comment", color:"#17C3E6" },
];

/* =================================================================
   STATE
================================================================= */
const CPSTATE = {
  dark:false, view:"splash", modal:null, editingProfile:false,
  profileTab:"posts", friendsTab:"all", exploreTab:"trending",
  settingsTab:"general", adminTab:"overview",
  groupsDetail:null, groupsCreating:false, marketProduct:null,
  chatActiveId:1, chatCall:null, chatShowMedia:false,
  priv:{ privateAccount:false, activityStatus:true },
};

function setView(v){ CPSTATE.view=v; CPSTATE.modal=null; cpRender(); window.scrollTo(0,0); }
function setDark(v){ CPSTATE.dark=v; var el=document.getElementById('chatpoa-app'); if(el) el.setAttribute('data-theme', v?'dark':'light'); cpRender(); }
function openModal(type, payload){ CPSTATE.modal={type, ...payload}; cpRender(); }
function closeModal(){ CPSTATE.modal=null; cpRender(); }

/* =================================================================
   PRIMITIVES
================================================================= */
function avatarHTML(p, size, ring){
  size = size||40;
  const inner = `<div class="avatar" style="width:${size}px;height:${size}px;background:${p.grad};font-size:${size*0.36}px;${ring?`border:2px solid var(--surface);`:''}">${p.initials}</div>`;
  return ring ? `<div class="avatar-ring" style="width:${size+6}px;height:${size+6}px;">${inner}</div>` : inner;
}
function nameRowHTML(p, size){
  size = size||14.5;
  return `<span class="name-row" style="font-size:${size}px;">${p.name}${p.verified?cpIcon('circle-check',size,'#2F6BFF'):''}</span>`;
}
function cpBtn(label, variant, extraAttrs, iconName, full){
  return `<button class="btn btn-${variant||'secondary'} ${full?'btn-full':''}" ${extraAttrs||''}>${iconName?cpIcon(iconName,15):''}${label}</button>`;
}
function iconBtn(name, onclick, active, badge){
  return `<button class="icon-btn ${active?'active':''}" onclick="${onclick}">${cpIcon(name,18)}${badge?`<span class="badge-dot">${badge}</span>`:''}</button>`;
}

/* =================================================================
   LOGO
================================================================= */
function logoSVG(size){
  size = size||32;
  return `<svg width="${size}" height="${size}" viewBox="0 0 64 64" fill="none">
    <defs><linearGradient id="poaG" x1="4" y1="4" x2="60" y2="60" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="#2F6BFF"/><stop offset="1" stop-color="#17C3E6"/>
    </linearGradient></defs>
    <rect x="4" y="4" width="56" height="56" rx="18" fill="url(#poaG)"/>
    <path d="M32 17c-9.4 0-17 6.6-17 14.7 0 4.4 2.2 8.4 5.8 11.1l-1.2 6.4 7-3.6c1.7.5 3.5.7 5.4.7 9.4 0 17-6.6 17-14.6S41.4 17 32 17z" fill="#fff"/>
    <circle cx="24.5" cy="31.6" r="2.6" fill="url(#poaG)"/><circle cx="32" cy="31.6" r="2.6" fill="url(#poaG)"/><circle cx="39.5" cy="31.6" r="2.6" fill="url(#poaG)"/>
  </svg>`;
}

/* =================================================================
   AUTH SCREENS
================================================================= */
function fieldHTML(label, placeholder, id, toggle){
  return `<label class="field">
    <span>${label}</span>
    <div style="position:relative;">
      <input id="${id}" type="${toggle?'password':'text'}" placeholder="${placeholder}" />
      ${toggle?`<button type="button" onclick="const i=document.getElementById('${id}');i.type=i.type==='password'?'text':'password';" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--text3);cursor:pointer;">${cpIcon('eye',17)}</button>`:''}
    </div>
  </label>`;
}
function renderAuth(view){
  const box = (inner) => `<div class="auth-shell"><div class="auth-box">${inner}</div></div>`;
  if(view==='splash') return box(`
    <div style="text-align:center;">
      <div style="margin:0 auto 20px;width:84px;">${logoSVG(84)}</div>
      <div style="font-weight:800;font-size:26px;letter-spacing:-.02em;">ChatPoa</div>
      <div style="font-size:14px;color:var(--text2);margin-top:6px;">Where the world stays in touch</div>
      <div style="margin:40px auto 0;width:28px;height:28px;border-radius:50%;border:3px solid var(--line);border-top-color:#2F6BFF;animation:poaSpin .9s linear infinite;"></div>
      <div style="margin-top:24px;">${cpBtn('Skip','ghost',`onclick="setView('welcome')"`)}</div>
    </div>`);
  if(view==='welcome') return box(`
    <div style="width:56px;margin-bottom:24px;">${logoSVG(56)}</div>
    <h1 style="font-size:30px;font-weight:800;letter-spacing:-.02em;line-height:1.15;margin:0 0 10px;">Connect with people who get you.</h1>
    <p style="font-size:15px;color:var(--text2);line-height:1.6;margin:0 0 32px;">Posts, communities, marketplace and messaging — one clean, fast home for it all.</p>
    ${cpBtn('Create account','primary',`style="margin-bottom:10px;" onclick="setView('register')"`,'arrow-right',true)}
    ${cpBtn('Log in','secondary',`onclick="setView('login')"`,null,true)}`);
  if(view==='login') return box(`
    <div style="margin-bottom:28px;">${logoSVG(40)}</div>
    <h2 style="font-size:22px;font-weight:700;margin:0 0 20px;">Log in to ChatPoa</h2>
    ${fieldHTML('Email','name@company.com','login-email')}
    ${fieldHTML('Password','Enter your password','login-pass',true)}
    <div style="text-align:right;margin-bottom:20px;"><span onclick="setView('forgot')" style="font-size:13px;color:#2F6BFF;cursor:pointer;font-weight:600;">Forgot password?</span></div>
    ${cpBtn('Log in','primary',`onclick="setView('home')"`,null,true)}
    <div style="text-align:center;margin-top:18px;font-size:13.5px;color:var(--text2);">New here? <span onclick="setView('register')" style="color:#2F6BFF;font-weight:600;cursor:pointer;">Create an account</span></div>`);
  if(view==='register') return box(`
    <div style="margin-bottom:28px;">${logoSVG(40)}</div>
    <h2 style="font-size:22px;font-weight:700;margin:0 0 20px;">Create your account</h2>
    ${fieldHTML('Full name','Jordan Lee','reg-name')}
    ${fieldHTML('Email','name@company.com','reg-email')}
    ${fieldHTML('Password','At least 8 characters','reg-pass',true)}
    ${cpBtn('Continue','primary',`style="margin-top:6px;" onclick="setView('verify')"`,null,true)}
    <div style="text-align:center;margin-top:18px;font-size:13.5px;color:var(--text2);">Already have an account? <span onclick="setView('login')" style="color:#2F6BFF;font-weight:600;cursor:pointer;">Log in</span></div>`);
  if(view==='verify') return box(`
    <div class="empty-icon" style="margin:0 0 20px;">${cpIcon('envelope',24,'#2F6BFF')}</div>
    <h2 style="font-size:21px;font-weight:700;margin:0 0 8px;">Check your inbox</h2>
    <p style="font-size:14px;color:var(--text2);margin:0 0 24px;">We sent a 6-digit code to your email. Enter it below to verify your account.</p>
    <div style="display:flex;gap:10px;margin-bottom:24px;">${[0,1,2,3,4,5].map(()=>`<input maxlength="1" style="width:44px;height:52px;text-align:center;font-size:18px;font-weight:700;border-radius:10px;border:1px solid var(--line);background:var(--surface2);color:var(--text1);outline:none;" />`).join('')}</div>
    ${cpBtn('Verify','primary',`onclick="setView('username')"`,null,true)}`);
  if(view==='forgot') return box(`
    <h2 style="font-size:21px;font-weight:700;margin:0 0 8px;">Reset your password</h2>
    <p style="font-size:14px;color:var(--text2);margin:0 0 20px;">Enter the email on your account and we'll send a reset link.</p>
    ${fieldHTML('Email','name@company.com','forgot-email')}
    ${cpBtn('Send reset link','primary',`onclick="setView('reset')"`,null,true)}
    <div style="text-align:center;margin-top:18px;"><span onclick="setView('login')" style="font-size:13.5px;color:var(--text2);cursor:pointer;">← Back to log in</span></div>`);
  if(view==='reset') return box(`
    <h2 style="font-size:21px;font-weight:700;margin:0 0 20px;">Set a new password</h2>
    ${fieldHTML('New password','At least 8 characters','reset-pass',true)}
    ${fieldHTML('Confirm password','Re-enter password','reset-pass2',true)}
    ${cpBtn('Update password','primary',`onclick="setView('login')"`,null,true)}`);
  if(view==='username') return box(`
    <h2 style="font-size:21px;font-weight:700;margin:0 0 8px;">Choose a username</h2>
    <p style="font-size:14px;color:var(--text2);margin:0 0 20px;">This is how people will find you on ChatPoa.</p>
    ${fieldHTML('Username','jordanlee','username-field')}
    ${cpBtn('Finish setup','primary',`onclick="setView('home')"`,null,true)}`);
}

/* =================================================================
   POST + STORIES
================================================================= */
function storyRailHTML(){
  return `<div class="story-rail">${[CPME,...PEOPLE].map((p,i)=>`
    <div class="story-item" style="background:${p.grad};">
      <div class="story-fade"></div>
      <div style="position:absolute;top:8px;left:8px;width:28px;height:28px;border-radius:50%;border:2.5px solid #fff;background:var(--surface);"></div>
      <div class="story-label">${i===0?'Your story':p.name.split(' ')[0]}</div>
    </div>`).join('')}</div>`;
}
function postCardHTML(p){
  return `<div class="card post-card">
    <div class="post-top">
      <div style="display:flex;align-items:center;gap:10px;">
        ${avatarHTML(p.user,42)}
        <div>${nameRowHTML(p.user)}<div style="font-size:12.5px;color:var(--text3);">${p.time} · public</div></div>
      </div>
      ${cpIcon('ellipsis',18,'var(--text3)')}
    </div>
    <p class="post-text">${p.text}</p>
    ${p.tag?`<span class="post-tag">#${p.tag}</span>`:''}
    <div class="post-actions">
      <button onclick="toggleLike(${p.id})" style="color:${p.liked?'#2F6BFF':'var(--text2)'};">${cpIcon(p.liked?'thumbs-up':'thumbs-up',17)} ${p.likes}</button>
      <button onclick="openModal('comments',{postId:${p.id}})">${cpIcon('comment',17)} ${p.comments}</button>
      <button onclick="openModal('share',{})">${cpIcon('share-nodes',16)} Share</button>
      <button>${cpIcon('bookmark',17)}</button>
    </div>
  </div>`;
}
function toggleLike(id){
  const p = POSTS.find(x=>x.id===id);
  if(!p) return;
  p.liked = !p.liked;
  p.likes += p.liked ? 1 : -1;
  cpRender();
}
function addPost(){
  const text = document.getElementById('compose-text').value.trim();
  if(!text) return;
  POSTS.unshift({ id:Date.now(), user:CPME, time:"just now", text, likes:0, comments:0, liked:false });
  closeModal();
}

/* =================================================================
   SCREEN: Home
================================================================= */
function renderHome(){
  return `<div style="max-width:620px;margin:0 auto;padding:16px 14px;">
    <div class="card" style="margin-bottom:14px;">${storyRailHTML()}</div>
    <div class="card" style="padding:14px;margin-bottom:14px;display:flex;align-items:center;gap:10px;">
      ${avatarHTML(CPME,38)}
      <button onclick="openModal('compose',{})" style="flex:1;text-align:left;padding:10px 16px;border-radius:999px;border:none;background:var(--surface2);color:var(--text3);font-size:14px;cursor:pointer;">What's on your mind, ${CPME.name.split(' ')[0]}?</button>
      ${iconBtn('image', "openModal('compose',{})")}
    </div>
    ${POSTS.map(postCardHTML).join('')}
  </div>`;
}

/* =================================================================
   SCREEN: Profile
================================================================= */
function setProfileTab(t){ CPSTATE.profileTab=t; cpRender(); }
function renderProfile(self){
  const person = self ? CPME : PEOPLE[0];
  const mine = POSTS.filter(p=>p.user.handle===person.handle);
  const tabs = ['posts','photos','about'];
  return `<div style="max-width:760px;margin:0 auto;">
    <div style="height:220px;background:var(--grad);border-radius:0 0 20px 20px;position:relative;">
      ${self?`<button style="position:absolute;right:16px;bottom:16px;background:rgba(0,0,0,.35);border:none;color:#fff;border-radius:10px;padding:8px 14px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:6px;cursor:pointer;">${cpIcon('camera',15)} Edit cover</button>`:''}
    </div>
    <div style="padding:0 20px;">
      <div style="display:flex;align-items:flex-end;justify-content:space-between;margin-top:-48px;">
        ${avatarHTML(person,104,true)}
        ${self? cpBtn('Edit profile','secondary',`onclick="CPSTATE.editingProfile=true;cpRender();"`,'pen') :
          `<div style="display:flex;gap:8px;">${cpBtn('Add friend','primary','','user-plus')}${cpBtn('Message','secondary','','message')}</div>`}
      </div>
      <div style="margin-top:12px;">${nameRowHTML(person,22)}<div style="font-size:14px;color:var(--text2);">${person.handle}</div></div>
      <p style="font-size:14.5px;line-height:1.5;margin:12px 0;">Product designer. Building calm software. Coffee enthusiast.</p>
      <div style="display:flex;gap:22px;font-size:13.5px;color:var(--text2);padding-bottom:14px;">
        <span><b style="color:var(--text1);">842</b> Friends</span><span><b style="color:var(--text1);">3.1K</b> Followers</span>
      </div>
      <div style="display:flex;gap:22px;border-top:1px solid var(--line);border-bottom:1px solid var(--line);padding:12px 0;">
        ${tabs.map(tb=>`<span class="tab ${CPSTATE.profileTab===tb?'active':''}" style="text-transform:capitalize;" onclick="setProfileTab('${tb}')">${tb}</span>`).join('')}
      </div>
    </div>
    <div style="padding:16px 20px;">
      ${CPSTATE.profileTab==='posts' ? (mine.length? mine.map(postCardHTML).join('') :
        `<div class="empty-state"><div class="empty-icon">${cpIcon('pen',24,'var(--text3)')}</div><div style="font-weight:700;font-size:16px;color:var(--text1);margin-bottom:6px;">Nothing posted yet</div><div style="font-size:14px;margin-bottom:18px;">Share your first update with your friends.</div>${cpBtn('Create post','primary')}</div>`) : ''}
      ${CPSTATE.profileTab==='photos' ? `<div class="grid-3">${PEOPLE.map(p=>`<div style="aspect-ratio:1;border-radius:12px;background:${p.grad};"></div>`).join('')}</div>` : ''}
      ${CPSTATE.profileTab==='about' ? `<div class="card" style="padding:18px;">
        <div style="display:flex;gap:10px;align-items:center;margin-bottom:10px;font-size:14px;">${cpIcon('location-dot',16,'var(--text3)')} San Francisco, CA</div>
        <div style="display:flex;gap:10px;align-items:center;font-size:14px;">${cpIcon('users',16,'var(--text3)')} Joined March 2019</div></div>` : ''}
    </div>
  </div>
  ${CPSTATE.editingProfile? `<div class="modal-overlay" onclick="CPSTATE.editingProfile=false;cpRender();">
    <div class="modal" style="width:440px;" onclick="event.stopPropagation();">
      <div class="modal-head">Edit profile<button onclick="CPSTATE.editingProfile=false;cpRender();" style="border:none;background:transparent;color:var(--text2);cursor:pointer;">${cpIcon('xmark',20)}</button></div>
      <div class="modal-body">
        ${fieldHTML('Name',CPME.name,'edit-name')}
        ${fieldHTML('Bio','Product designer. Building calm software.','edit-bio')}
        ${cpBtn('Save changes','primary',`onclick="CPSTATE.editingProfile=false;cpRender();"`,null,true)}
      </div></div></div>`:''}`;
}

/* =================================================================
   SCREEN: Friends
================================================================= */
function setFriendsTab(t){ CPSTATE.friendsTab=t; cpRender(); }
function renderFriends(){
  const list = CPSTATE.friendsTab==='all' ? PEOPLE : PEOPLE.slice(0,2);
  return `<div style="max-width:760px;margin:0 auto;padding:18px 20px;">
    <div style="display:flex;gap:20px;margin-bottom:18px;">
      <span class="tab ${CPSTATE.friendsTab==='all'?'active':''}" style="font-size:15px;" onclick="setFriendsTab('all')">All friends</span>
      <span class="tab ${CPSTATE.friendsTab==='requests'?'active':''}" style="font-size:15px;" onclick="setFriendsTab('requests')">Requests · 2</span>
    </div>
    <div class="grid-auto">${list.map(p=>`
      <div class="card" style="padding:14px;text-align:center;">
        <div style="margin:0 auto 10px;display:flex;justify-content:center;">${avatarHTML(p,64)}</div>
        ${nameRowHTML(p)}
        <div style="font-size:12.5px;color:var(--text3);margin:4px 0 12px;">${Math.floor(Math.random()*20)+2} mutual friends</div>
        ${CPSTATE.friendsTab==='all'? cpBtn('Message','secondary','style="width:100%"') :
          `<div style="display:flex;gap:8px;">${cpBtn('Accept','primary','style="flex:1"')}${cpBtn('Decline','secondary','style="flex:1"')}</div>`}
      </div>`).join('')}</div>
  </div>`;
}

/* =================================================================
   SCREEN: Chat
================================================================= */
function setChatActive(id){ CPSTATE.chatActiveId=id; cpRender(); }
function sendChat(){
  const input = document.getElementById('chat-draft');
  const text = input.value.trim();
  if(!text) return;
  CHAT_THREADS[CPSTATE.chatActiveId].push({mine:true, text});
  input.value='';
  cpRender();
  const body = document.getElementById('chat-body');
  if(body) body.scrollTop = body.scrollHeight;
}
function startCall(kind){ CPSTATE.chatCall=kind; cpRender(); }
function endCall(){ CPSTATE.chatCall=null; cpRender(); }
function toggleMedia(){ CPSTATE.chatShowMedia=!CPSTATE.chatShowMedia; cpRender(); }
function renderChat(){
  const active = CONVERSATIONS.find(c=>c.id===CPSTATE.chatActiveId);
  const thread = CHAT_THREADS[CPSTATE.chatActiveId];
  return `<div class="chat-layout">
    <div class="chat-list hide-sm">
      <div style="padding:16px 18px 8px;font-weight:700;font-size:18px;">Chats</div>
      ${CONVERSATIONS.map(c=>`
        <button class="chat-item ${CPSTATE.chatActiveId===c.id?'active':''}" onclick="setChatActive(${c.id})">
          ${avatarHTML(c.person,44)}
          <div style="flex:1;min-width:0;">
            <div style="display:flex;justify-content:space-between;">${nameRowHTML(c.person,13.5)}<span style="font-size:11px;color:var(--text3);">${c.time}</span></div>
            <div style="font-size:12.5px;color:var(--text2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${c.last}</div>
          </div>
          ${c.unread>0?`<span style="background:var(--grad);color:#fff;font-size:10px;font-weight:700;border-radius:999px;min-width:17px;height:17px;display:flex;align-items:center;justify-content:center;">${c.unread}</span>`:''}
        </button>`).join('')}
    </div>
    <div class="chat-main">
      <div class="chat-head">
        ${avatarHTML(active.person,38)}${nameRowHTML(active.person)}
        <div style="margin-left:auto;display:flex;gap:4px;">
          ${iconBtn('phone',"startCall('voice')")}
          ${iconBtn('video',"startCall('video')")}
          ${iconBtn('image',"toggleMedia()")}
        </div>
      </div>
      ${CPSTATE.chatShowMedia?`<div style="display:flex;gap:8px;padding:12px 20px;border-bottom:1px solid var(--line);overflow-x:auto;">${PEOPLE.map(p=>`<div style="width:56px;height:56px;border-radius:10px;background:${p.grad};flex-shrink:0;"></div>`).join('')}</div>`:''}
      <div class="chat-body" id="chat-body">
        ${thread.map(m=>`<div class="bubble ${m.mine?'mine':'theirs'}">${m.text}</div>`).join('')}
      </div>
      <div class="chat-input-row">
        <input id="chat-draft" placeholder="Message..." onkeydown="if(event.key==='Enter')sendChat();" />
        ${iconBtn('microphone','')}
        <button class="send-cpBtn" onclick="sendChat()">${cpIcon('paper-plane',16)}</button>
      </div>
    </div>
    ${CPSTATE.chatCall? `<div class="call-overlay">
      ${avatarHTML(active.person,110)}
      <div style="font-weight:700;font-size:20px;margin-top:16px;">${active.person.name}</div>
      <div style="color:#9AA4B8;margin-top:4px;">${CPSTATE.chatCall==='voice'?'Voice call':'Video call'} · 00:14</div>
      <div style="display:flex;gap:16px;margin-top:40px;">
        <button style="width:52px;height:52px;border-radius:50%;border:none;background:#1F2937;color:#fff;cursor:pointer;">${cpIcon('microphone',20)}</button>
        <button onclick="endCall()" style="width:52px;height:52px;border-radius:50%;border:none;background:#EF4444;color:#fff;cursor:pointer;">${cpIcon('phone',20)}</button>
      </div>
    </div>`:''}
  </div>`;
}

/* =================================================================
   SCREEN: Groups
================================================================= */
function openGroup(i){ CPSTATE.groupsDetail=i; cpRender(); }
function closeGroup(){ CPSTATE.groupsDetail=null; cpRender(); }
function renderGroups(){
  if(CPSTATE.groupsDetail!==null){
    const g = GROUPS[CPSTATE.groupsDetail];
    return `<div style="max-width:760px;margin:0 auto;">
      <div style="height:160px;background:${g.cover};border-radius:0 0 18px 18px;position:relative;">
        <button onclick="closeGroup()" style="position:absolute;top:14px;left:14px;background:rgba(0,0,0,.35);border:none;color:#fff;border-radius:50%;width:34px;height:34px;cursor:pointer;">${cpIcon('chevron-left',18)}</button>
      </div>
      <div style="padding:20px;">
        <div style="font-weight:800;font-size:21px;">${g.name}</div>
        <div style="font-size:13.5px;color:var(--text2);margin:4px 0 14px;">${g.members} members · Public group</div>
        ${cpBtn('Joined','primary','style="width:100%"','circle-check')}
        <div style="margin-top:18px;">${POSTS.slice(0,2).map(postCardHTML).join('')}</div>
      </div></div>`;
  }
  return `<div style="max-width:900px;margin:0 auto;padding:18px 20px;">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
      <span style="font-weight:700;font-size:19px;">Your groups</span>
      ${cpBtn('Create group','primary',`onclick="CPSTATE.groupsCreating=true;cpRender();"`,'plus')}
    </div>
    <div class="grid-auto">${GROUPS.map((g,i)=>`
      <div class="card" style="overflow:hidden;cursor:pointer;">
        <div onclick="openGroup(${i})" style="height:100px;background:${g.cover};"></div>
        <div style="padding:14px;">
          <div style="font-weight:700;font-size:15px;">${g.name}</div>
          <div style="font-size:12.5px;color:var(--text2);margin:4px 0 10px;">${g.members} members</div>
          ${cpBtn('View group','secondary','style="width:100%" onclick="openGroup('+i+')"')}
        </div></div>`).join('')}</div>
    ${CPSTATE.groupsCreating? `<div class="modal-overlay" onclick="CPSTATE.groupsCreating=false;cpRender();">
      <div class="modal" style="width:420px;" onclick="event.stopPropagation();">
        <div class="modal-head">Create group<button onclick="CPSTATE.groupsCreating=false;cpRender();" style="border:none;background:transparent;color:var(--text2);cursor:pointer;">${cpIcon('xmark',20)}</button></div>
        <div class="modal-body">
          ${fieldHTML('Group name','e.g. Weekend Hikers','group-name')}
          ${fieldHTML('Description',"What's this group about?",'group-desc')}
          ${cpBtn('Create','primary',`onclick="CPSTATE.groupsCreating=false;cpRender();"`,null,true)}
        </div></div></div>`:''}
  </div>`;
}

/* =================================================================
   SCREEN: Pages / Events
================================================================= */
function renderPages(){
  const names = ["ChatPoa Design","Global Makers Co.","Studio North"];
  return `<div style="max-width:900px;margin:0 auto;padding:18px 20px;">
    <span style="font-weight:700;font-size:19px;">Pages you follow</span>
    <div class="grid-auto" style="margin-top:16px;">${names.map((n,i)=>`
      <div class="card" style="padding:16px;display:flex;align-items:center;gap:12px;">
        <div style="width:52px;height:52px;border-radius:12px;background:${PEOPLE[i].grad};flex-shrink:0;"></div>
        <div style="flex:1;min-width:0;">
          <div style="font-weight:700;font-size:14.5px;display:flex;align-items:center;gap:4px;">${n} ${cpIcon('circle-check',14,'#2F6BFF')}</div>
          <div style="font-size:12.5px;color:var(--text2);">${(i+3)*4.2}K followers</div>
        </div></div>`).join('')}</div></div>`;
}
function renderEvents(){
  return `<div style="max-width:900px;margin:0 auto;padding:18px 20px;">
    <span style="font-weight:700;font-size:19px;">Upcoming events</span>
    <div class="grid-auto" style="margin-top:16px;">${EVENTS.map(e=>`
      <div class="card" style="overflow:hidden;">
        <div style="height:110px;background:${e.cover};"></div>
        <div style="padding:14px;">
          <div style="font-weight:700;font-size:15px;">${e.name}</div>
          <div style="display:flex;gap:6px;align-items:center;font-size:12.5px;color:var(--text2);margin:6px 0 12px;">${cpIcon('calendar',13)} ${e.date} · ${cpIcon('location-dot',13)} ${e.loc}</div>
          ${cpBtn('Interested','primary','style="width:100%"')}
        </div></div>`).join('')}</div></div>`;
}

/* =================================================================
   SCREEN: Explore
================================================================= */
function setExploreTab(t){ CPSTATE.exploreTab=t; cpRender(); }
function renderExplore(){
  return `<div style="max-width:900px;margin:0 auto;padding:18px 20px;">
    <div style="display:flex;align-items:center;gap:10px;background:var(--surface2);border-radius:999px;padding:10px 16px;margin-bottom:16px;">
      ${cpIcon('magnifying-glass',16,'var(--text3)')}<input placeholder="Search people, hashtags, posts" style="border:none;background:transparent;outline:none;font-size:14px;color:var(--text1);width:100%;" />
    </div>
    <div style="display:flex;gap:20px;margin-bottom:16px;">
      ${['trending','hashtags','people'].map(k=>`<span class="tab ${CPSTATE.exploreTab===k?'active':''}" onclick="setExploreTab('${k}')">${k==='trending'?'Trending':k==='hashtags'?'Hashtags':'Suggested'}</span>`).join('')}
    </div>
    ${CPSTATE.exploreTab==='trending'? `<div class="grid-3">${PEOPLE.map(p=>`<div style="aspect-ratio:1;border-radius:12px;background:${p.grad};"></div>`).join('')}</div>`:''}
    ${CPSTATE.exploreTab==='hashtags'? ["#DesignSystems","#RemoteWork","#IndieMakers","#ChatPoaSummit"].map(h=>`
      <div style="display:flex;align-items:center;gap:10px;padding:12px 0;border-bottom:1px solid var(--line);">
        <div style="width:40px;height:40px;border-radius:50%;background:var(--surface2);display:flex;align-items:center;justify-content:center;">${cpIcon('hashtag',17,'#2F6BFF')}</div>
        <div><div style="font-weight:600;font-size:14.5px;">${h}</div><div style="font-size:12.5px;color:var(--text2);">12.4K posts</div></div>
      </div>`).join(''):''}
    ${CPSTATE.exploreTab==='people'? PEOPLE.map(p=>`
      <div style="display:flex;align-items:center;gap:10px;padding:10px 0;">
        ${avatarHTML(p,40)}<div style="flex:1;">${nameRowHTML(p)}<div style="font-size:12.5px;color:var(--text2);">${p.handle}</div></div>
        ${cpBtn('Follow','secondary','','user-plus')}
      </div>`).join(''):''}
  </div>`;
}

/* =================================================================
   SCREEN: Reels / Photos / Live
================================================================= */
function renderReels(){
  return `<div style="max-width:900px;margin:0 auto;padding:18px 20px;">
    <span style="font-weight:700;font-size:19px;">Reels</span>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px;margin-top:16px;">
      ${[...PEOPLE,...PEOPLE].map(p=>`<div style="aspect-ratio:9/16;border-radius:14px;background:${p.grad};position:relative;cursor:pointer;display:flex;align-items:center;justify-content:center;">${cpIcon('circle-play',26,'#fff')}</div>`).join('')}
    </div></div>`;
}
function renderPhotos(){
  return `<div style="max-width:900px;margin:0 auto;padding:18px 20px;">
    <span style="font-weight:700;font-size:19px;">Photos</span>
    <div class="grid-4" style="margin-top:16px;">${[...PEOPLE,...PEOPLE].map(p=>`<div style="aspect-ratio:1;border-radius:12px;background:${p.grad};"></div>`).join('')}</div></div>`;
}
function renderLive(){
  return `<div style="max-width:900px;margin:0 auto;padding:18px 20px;">
    <span style="font-weight:700;font-size:19px;">Live now</span>
    <div class="grid-auto" style="margin-top:16px;">${PEOPLE.slice(0,2).map(p=>`
      <div class="card" style="overflow:hidden;">
        <div style="height:140px;background:${p.grad};position:relative;">
          <span style="position:absolute;top:10px;left:10px;background:#EF4444;color:#fff;font-size:11px;font-weight:700;padding:3px 9px;border-radius:999px;">● LIVE</span>
        </div>
        <div style="padding:14px;display:flex;gap:10px;align-items:center;">
          ${avatarHTML(p,34)}<div><div style="font-weight:600;font-size:13.5px;">${p.name}</div><div style="font-size:12px;color:var(--text2);">1.2K watching</div></div>
        </div></div>`).join('')}</div></div>`;
}

/* =================================================================
   SCREEN: Notifications / Saved
================================================================= */
function renderNotifications(){
  return `<div style="max-width:620px;margin:0 auto;">
    <div class="section-header">Notifications</div>
    ${NOTIFS.map(n=>`
      <div style="display:flex;align-items:center;gap:14px;padding:14px 20px;border-bottom:1px solid var(--line);">
        ${cpIcon(n.icon,18,n.color)}${avatarHTML(n.person,38)}
        <div style="flex:1;font-size:14px;"><span style="font-weight:600;">${n.person.name}</span> ${n.text}</div>
        <span style="font-size:12px;color:var(--text3);">${n.time}</span>
      </div>`).join('')}
  </div>`;
}
function renderSaved(){
  return `<div style="max-width:620px;margin:0 auto;padding:18px 20px;">
    <span style="font-weight:700;font-size:19px;">Saved</span>
    <div style="margin-top:14px;">${POSTS.slice(0,1).map(postCardHTML).join('')}</div></div>`;
}

/* =================================================================
   SCREEN: Settings
================================================================= */
function setSettingsTab(t){ CPSTATE.settingsTab=t; cpRender(); }
function toggleHTML(on, onclick){
  return `<button class="toggle ${on?'toggle-on':'toggle-off'}" onclick="${onclick}"><span class="toggle-knob" style="left:${on?'21px':'3px'};"></span></button>`;
}
function settingsRow(iconName, label, sub, right){
  return `<div class="settings-row">
    <div class="settings-icon">${cpIcon(iconName,17)}</div>
    <div style="flex:1;"><div style="font-size:14.5px;font-weight:600;">${label}</div>${sub?`<div style="font-size:12.5px;color:var(--text2);">${sub}</div>`:''}</div>
    ${right||''}
  </div>`;
}
function renderSettings(){
  const tabs = [['general','General'],['privacy','Privacy'],['security','Security'],['blocked','Blocked'],['language','Language']];
  let body = '';
  if(CPSTATE.settingsTab==='general') body = settingsRow(CPSTATE.dark?'sun':'moon','Dark mode','Switch the whole app to a dark palette', toggleHTML(CPSTATE.dark, "setDark(!CPSTATE.dark)"));
  if(CPSTATE.settingsTab==='privacy') body = settingsRow('lock','Private account','Only friends can see your posts', toggleHTML(CPSTATE.priv.privateAccount, "CPSTATE.priv.privateAccount=!CPSTATE.priv.privateAccount;cpRender();"))
    + settingsRow('eye','Activity status',"Show when you're active on ChatPoa", toggleHTML(CPSTATE.priv.activityStatus, "CPSTATE.priv.activityStatus=!CPSTATE.priv.activityStatus;cpRender();"));
  if(CPSTATE.settingsTab==='security') body = settingsRow('shield-halved','Two-factor authentication','Add an extra layer of security', cpBtn('Enable','secondary'))
    + settingsRow('lock','Change password','', cpIcon('chevron-right',16,'var(--text3)'));
  if(CPSTATE.settingsTab==='blocked') body = settingsRow('ban','Blocked users',"You haven't blocked anyone",'<span style="font-size:13px;color:var(--text3);">0</span>');
  if(CPSTATE.settingsTab==='language') body = settingsRow('globe','App language','English (US)', cpIcon('chevron-right',16,'var(--text3)'));
  return `<div style="max-width:760px;margin:0 auto;padding:18px 20px;">
    <span style="font-weight:700;font-size:19px;">Settings</span>
    <div style="display:flex;gap:18px;margin:16px 0;overflow-x:auto;">${tabs.map(([k,l])=>`<span class="tab ${CPSTATE.settingsTab===k?'active':''}" style="white-space:nowrap;" onclick="setSettingsTab('${k}')">${l}</span>`).join('')}</div>
    <div class="card" style="padding:4px 16px;">${body}</div>
    ${cpBtn('Log out','danger','style="width:100%;margin-top:16px;"','right-from-bracket')}
  </div>`;
}

/* =================================================================
   SCREEN: Marketplace
================================================================= */
function openProduct(i){ CPSTATE.marketProduct=i; cpRender(); }
function closeProduct(){ CPSTATE.marketProduct=null; cpRender(); }
function renderMarketplace(){
  if(CPSTATE.marketProduct!==null){
    const p = PRODUCTS[CPSTATE.marketProduct];
    return `<div style="max-width:700px;margin:0 auto;padding:18px 20px;">
      <button onclick="closeProduct()" style="display:flex;align-items:center;gap:6px;border:none;background:transparent;color:var(--text2);cursor:pointer;margin-bottom:14px;">${cpIcon('chevron-left',16)} Back to marketplace</button>
      <div style="height:260px;border-radius:16px;background:${p.cover};margin-bottom:16px;"></div>
      <div style="font-weight:800;font-size:22px;">${p.price}</div>
      <div style="font-size:15px;margin:4px 0 16px;">${p.name}</div>
      <div class="card" style="padding:14px;display:flex;align-items:center;gap:12px;margin-bottom:16px;">
        ${avatarHTML(p.seller,42)}<div style="flex:1;">${nameRowHTML(p.seller)}<div style="font-size:12.5px;color:var(--text2);">Usually responds within an hour</div></div>
        ${cpBtn('View profile','secondary')}
      </div>
      ${cpBtn('Message seller','primary','style="width:100%"','message')}
    </div>`;
  }
  return `<div style="max-width:900px;margin:0 auto;padding:18px 20px;">
    <span style="font-weight:700;font-size:19px;">Marketplace</span>
    <div class="grid-auto" style="margin-top:16px;">${[...PRODUCTS,...PRODUCTS].map((p,i)=>`
      <div class="card" style="overflow:hidden;cursor:pointer;" onclick="openProduct(${i % PRODUCTS.length})">
        <div style="aspect-ratio:1;background:${p.cover};"></div>
        <div style="padding:12px;"><div style="font-weight:700;font-size:14px;">${p.price}</div><div style="font-size:12.5px;color:var(--text2);">${p.name}</div></div>
      </div>`).join('')}</div></div>`;
}

/* =================================================================
   SCREEN: Creator / Admin
================================================================= */
function renderCreator(){
  const stats = [['Followers','18.4K','users'],['Post reach (30d)','482K','arrow-trend-up'],['Earnings (30d)','$1,240','dollar-sign']];
  return `<div style="max-width:900px;margin:0 auto;padding:18px 20px;">
    <span style="font-weight:700;font-size:19px;">Creator studio</span>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin:16px 0;">
      ${stats.map(([l,v,i])=>`<div class="card" style="padding:16px;">${cpIcon(i,18,'#2F6BFF')}<div style="font-size:22px;font-weight:800;margin-top:10px;">${v}</div><div style="font-size:12.5px;color:var(--text2);">${l}</div></div>`).join('')}
    </div>
    <div class="card" style="padding:18px;margin-bottom:14px;">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">${cpIcon('circle-check',20,'#2F6BFF')}<span style="font-weight:700;font-size:15px;">Get verified</span></div>
      <p style="font-size:13.5px;color:var(--text2);margin:0 0 12px;">Verification confirms your identity and adds a badge to your profile.</p>
      ${cpBtn('Apply for verification','primary')}
    </div>
    <div class="card" style="padding:18px;">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">${cpIcon('dollar-sign',20,'#17C3E6')}<span style="font-weight:700;font-size:15px;">Monetization</span></div>
      <p style="font-size:13.5px;color:var(--text2);margin:0 0 12px;">You're eligible for fan subscriptions and in-stream ads.</p>
      ${cpBtn('Set up payouts','secondary')}
    </div>
  </div>`;
}
function setAdminTab(t){ CPSTATE.adminTab=t; cpRender(); }
function renderAdmin(){
  const stats = [['Total users','4.2M'],['Daily active','1.8M'],['Open reports','312'],['New signups today','9.4K']];
  const tabs = [['overview','Overview'],['users','User management'],['reports','Reports']];
  let body = '';
  if(CPSTATE.adminTab==='overview') body = `<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px;">${stats.map(([l,v])=>`<div class="card" style="padding:16px;">${cpIcon('chart-simple',17,'#2F6BFF')}<div style="font-size:21px;font-weight:800;margin-top:8px;">${v}</div><div style="font-size:12.5px;color:var(--text2);">${l}</div></div>`).join('')}</div>`;
  if(CPSTATE.adminTab==='users') body = `<div class="card" style="padding:6px;">${PEOPLE.map(p=>`
    <div style="display:flex;align-items:center;gap:12px;padding:12px 10px;border-bottom:1px solid var(--line);">
      ${avatarHTML(p,34)}<div style="flex:1;">${nameRowHTML(p,13.5)}<div style="font-size:12px;color:var(--text2);">${p.handle}</div></div>${cpBtn('Manage','secondary')}
    </div>`).join('')}</div>`;
  if(CPSTATE.adminTab==='reports') body = `<div class="card" style="padding:6px;">${["Spam post flagged by 12 users","Impersonation report on @tombecker","Harassment report in Indie Makers group"].map(r=>`
    <div style="display:flex;align-items:center;gap:12px;padding:12px 10px;border-bottom:1px solid var(--line);">${cpIcon('flag',16,'#EF4444')}<span style="flex:1;font-size:13.5px;">${r}</span>${cpBtn('Review','secondary')}</div>`).join('')}</div>`;
  return `<div style="max-width:1000px;margin:0 auto;padding:18px 20px;">
    <span style="font-weight:700;font-size:19px;">Admin dashboard</span>
    <div style="display:flex;gap:20px;margin:16px 0;">${tabs.map(([k,l])=>`<span class="tab ${CPSTATE.adminTab===k?'active':''}" onclick="setAdminTab('${k}')">${l}</span>`).join('')}</div>
    ${body}
  </div>`;
}

/* =================================================================
   MODALS
================================================================= */
function renderModal(){
  if(!CPSTATE.modal) return '';
  if(CPSTATE.modal.type==='compose') return `<div class="modal-overlay" onclick="closeModal()">
    <div class="modal" style="width:480px;" onclick="event.stopPropagation();">
      <div class="modal-head">Create post<button onclick="closeModal()" style="border:none;background:transparent;color:var(--text2);cursor:pointer;">${cpIcon('xmark',20)}</button></div>
      <div class="modal-body">
        <div style="display:flex;gap:10px;align-items:center;margin-bottom:14px;">${avatarHTML(CPME,40)}${nameRowHTML(CPME)}</div>
        <textarea id="compose-text" autofocus placeholder="What's on your mind, ${CPME.name.split(' ')[0]}?" rows="5" style="width:100%;border:none;outline:none;resize:none;background:transparent;color:var(--text1);font-size:16px;"></textarea>
        <div style="display:flex;gap:10px;padding:12px 0;border-top:1px solid var(--line);margin-top:8px;">${iconBtn('image','')}${iconBtn('video','')}${iconBtn('location-dot','')}</div>
        ${cpBtn('Post','primary','style="width:100%" onclick="addPost()"')}
      </div></div></div>`;
  if(CPSTATE.modal.type==='comments'){
    const post = POSTS.find(p=>p.id===CPSTATE.modal.postId);
    const comments = [{person:PEOPLE[3],text:"This is so clean, congrats team!"},{person:PEOPLE[4],text:"Been waiting for this update"}];
    return `<div class="modal-overlay" onclick="closeModal()">
      <div class="modal" style="width:480px;" onclick="event.stopPropagation();">
        <div class="modal-head">Comments<button onclick="closeModal()" style="border:none;background:transparent;color:var(--text2);cursor:pointer;">${cpIcon('xmark',20)}</button></div>
        <div style="padding:14px 18px;border-bottom:1px solid var(--line);">${nameRowHTML(post.user)}<p style="font-size:14.5px;margin:6px 0 0;">${post.text}</p></div>
        <div style="padding:8px 18px;">${comments.map(c=>`
          <div style="display:flex;gap:10px;padding:10px 0;">${avatarHTML(c.person,32)}
            <div style="background:var(--surface2);border-radius:14px;padding:8px 12px;"><div style="font-size:13px;font-weight:600;">${c.person.name}</div><div style="font-size:13.5px;">${c.text}</div></div>
          </div>`).join('')}</div>
        <div style="display:flex;gap:10px;padding:14px;border-top:1px solid var(--line);">${avatarHTML(CPME,32)}<input placeholder="Write a comment..." style="flex:1;border:1px solid var(--line);background:var(--surface2);border-radius:999px;padding:9px 14px;color:var(--text1);outline:none;font-size:13.5px;" /></div>
      </div></div>`;
  }
  if(CPSTATE.modal.type==='share') return `<div class="modal-overlay" onclick="closeModal()">
    <div class="modal" style="width:380px;" onclick="event.stopPropagation();">
      <div class="modal-head">Share post<button onclick="closeModal()" style="border:none;background:transparent;color:var(--text2);cursor:pointer;">${cpIcon('xmark',20)}</button></div>
      <div class="modal-body" style="display:flex;flex-direction:column;gap:8px;">
        ${cpBtn('Share to your feed','secondary','style="width:100%"','share-nodes')}
        ${cpBtn('Send in a message','secondary','style="width:100%"','message')}
        ${cpBtn('Share to a group','secondary','style="width:100%"','users')}
      </div></div></div>`;
  return '';
}

/* =================================================================
   SHELL: TopNav / Sidebar / RightRail
================================================================= */
const NAV_SIDEBAR = [
  ['profile','Profile','users'],['friends','Friends','users'],['groups','Groups','users-rectangle'],
  ['pages','Pages','flag'],['events','Events','calendar'],['saved','Saved','bookmark'],
  ['reels','Reels','clapperboard'],['photos','Photos','image'],['live','Live','tower-broadcast'],
  ['marketplace','Marketplace','store'],['creator','Creator studio','chart-simple'],
  ['admin','Admin dashboard','table-columns'],['settings','Settings','gear'],
];
function topNavHTML(){
  return `<div class="topnav"><div class="topnav-inner">
    <div class="logo-wrap" onclick="setView('home')">${logoSVG(32)}<span class="logo-word hide-sm">ChatPoa</span></div>
    <div class="searchbox hide-sm">${cpIcon('magnifying-glass',16,'var(--text3)')}<input placeholder="Search ChatPoa" /></div>
    <div class="nav-icons">
      ${iconBtn('house',"setView('home')", CPSTATE.view==='home')}
      ${iconBtn('message',"setView('chat')", CPSTATE.view==='chat', 3)}
      ${iconBtn('bell',"setView('notifications')", CPSTATE.view==='notifications', NOTIFS.length)}
      ${iconBtn(CPSTATE.dark?'sun':'moon',"setDark(!CPSTATE.dark)")}
      <div onclick="setView('profile')" style="margin-left:6px;cursor:pointer;">${avatarHTML(CPME,34)}</div>
    </div>
  </div></div>`;
}
function sidebarHTML(){
  return `<aside class="sidebar hide-md">
    <button class="sidebar-cpBtn" onclick="setView('profile')">${avatarHTML(CPME,34)}<span style="font-weight:600;font-size:14px;">${CPME.name}</span></button>
    ${NAV_SIDEBAR.map(([k,l,i])=>`
      <button class="sidebar-cpBtn ${CPSTATE.view===k?'active':''}" onclick="setView('${k}')">
        <div class="sidebar-icon ${CPSTATE.view===k?'active':''}">${cpIcon(i,15)}</div>
        <span style="font-size:14px;font-weight:${CPSTATE.view===k?700:500};color:${CPSTATE.view===k?'var(--text1)':'var(--text2)'};">${l}</span>
      </button>`).join('')}
  </aside>`;
}
function rightRailHTML(){
  return `<aside class="rightrail hide-lg">
    <div class="card" style="padding:16px;margin-bottom:16px;">
      <div style="display:flex;align-items:center;gap:8px;font-weight:700;font-size:15px;margin-bottom:12px;">${cpIcon('arrow-trend-up',16,'#2F6BFF')} Trending</div>
      ${["#DesignSystems","#RemoteWork","#ChatPoaSummit","#IndieMakers"].map(h=>`<div style="display:flex;align-items:center;gap:8px;padding:7px 0;font-size:13.5px;cursor:pointer;">${cpIcon('hashtag',14,'var(--text3)')} ${h.slice(1)}</div>`).join('')}
    </div>
    <div class="card" style="padding:16px;">
      <div style="font-weight:700;font-size:15px;margin-bottom:12px;">People you may know</div>
      ${PEOPLE.slice(0,3).map(p=>`
        <div style="display:flex;align-items:center;gap:10px;padding:8px 0;">
          ${avatarHTML(p,36)}<div style="flex:1;min-width:0;"><div style="font-size:13.5px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${p.name}</div></div>
          <button style="width:30px;height:30px;border-radius:50%;border:1px solid var(--line);background:transparent;color:#2F6BFF;cursor:pointer;">${cpIcon('plus',15)}</button>
        </div>`).join('')}
    </div>
  </aside>`;
}

/* =================================================================
   ROOT RENDER
================================================================= */
const AUTH_VIEWS = ['splash','welcome','login','register','verify','forgot','reset','username'];
function cpRender(){
  const app = document.getElementById('chatpoa-app');
  if(AUTH_VIEWS.includes(CPSTATE.view)){
    app.innerHTML = renderAuth(CPSTATE.view);
    return;
  }
  const screens = {
    home: renderHome, profile: ()=>renderProfile(true), otherProfile: ()=>renderProfile(false),
    friends: renderFriends, chat: renderChat, groups: renderGroups, pages: renderPages,
    events: renderEvents, explore: renderExplore, reels: renderReels, photos: renderPhotos,
    live: renderLive, notifications: renderNotifications, saved: renderSaved,
    settings: renderSettings, marketplace: renderMarketplace, creator: renderCreator, admin: renderAdmin,
  };
  const screenFn = screens[CPSTATE.view] || renderHome;
  app.innerHTML = `
    ${topNavHTML()}
    <div class="shell">
      ${sidebarHTML()}
      <main>${screenFn()}</main>
      ${CPSTATE.view==='home' ? rightRailHTML() : ''}
    </div>
    ${CPSTATE.view==='home' ? `<button class="fab" onclick="openModal('compose',{})">${cpIcon('pen',20)}</button>` : ''}
    ${renderModal()}
  `;
}

function cpInit(){
  if(document.getElementById('chatpoa-app')) cpRender();
}
if(document.readyState === 'loading'){
  document.addEventListener('DOMContentLoaded', cpInit);
} else {
  cpInit();
}
